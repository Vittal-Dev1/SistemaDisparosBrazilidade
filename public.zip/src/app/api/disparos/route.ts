import { NextRequest, NextResponse } from "next/server";
import { supabase } from "../../lib/supabase";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* ========= ENV ========= */
const API_BASE = (process.env.UAZAPIGO_API_URL || process.env.UAZAPI_BASE_URL || "").replace(/\/$/, "");
const TOKEN_INSTANCIA = process.env.UAZAPIGO_TOKEN || process.env.UAZAPI_TOKEN || "";

/* ========= Tipos ========= */
type Contact = { nome?: string; numero: string };
type Job = {
  to: string;
  text: string;
  batchId: number;
  msgRowId?: number | null;
  scheduledAt: number; // epoch ms
};

type Batch = { id: number; createdAt: number; jobs: Job[]; inProgress: boolean };
type Store = { lastId: number; batches: Map<number, Batch>; processing: boolean };

/* ========= Store global ========= */
const getStore = (): Store => {
  const g = globalThis as any;
  if (!g.__DISPAROS_STORE__) {
    g.__DISPAROS_STORE__ = { lastId: 0, batches: new Map<number, Batch>(), processing: false } as Store;
  }
  return g.__DISPAROS_STORE__ as Store;
};

/* ========= Utils ========= */
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
const digits = (v: string) => (v || "").replace(/\D+/g, "");
const norm = (n: string) => {
  const d = digits(n ?? "");
  if (!d) return "";
  return d.startsWith("55") ? d : `55${d}`;
};
const now = () => Date.now();
const rand = (a: number, b: number) => {
  let min = Math.min(a, b), max = Math.max(a, b);
  if (min < 0) min = 0;
  return min + Math.floor(Math.random() * (max - min + 1));
};

/* ========= Janela 08–18 ========= */
const dentroHorario = () => {
  const h = new Date().getHours();
  return h >= 8 && h < 18;
};
const proxDiaUtil0800 = () => {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(8, 0, 0, 0);
  return d;
};

/* ========= Envio (com fallback 404) ========= */
/* ========= Envio (robusto com múltiplos fallbacks) ========= */
async function sendViaUazapi(to: string, text: string) {
  if (!API_BASE) throw new Error("UAZAPIGO_API_URL ausente");
  if (!TOKEN_INSTANCIA) throw new Error("UAZAPIGO_TOKEN ausente");

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json",
    token: TOKEN_INSTANCIA,
  };
  const body = JSON.stringify({ number: to, text });

  const parseBody = async (res: Response) => {
    const ct = res.headers.get("content-type") || "";
    if (ct.includes("application/json")) {
      try { return await res.json(); } catch { /* ignore */ }
    }
    const txt = await res.text().catch(() => "");
    // às vezes o servidor devolve texto, mas é um JSON válido
    try { return JSON.parse(txt); } catch { return txt; }
  };

  const tryPost = async (url: string) => {
    const res = await fetch(url, { method: "POST", headers, body });
    const data = await parseBody(res);
    return { res, data };
  };

  // Gera candidatos: aceita base OU endpoint completo
  const normalizeCandidates = (baseOrFull: string) => {
    const clean = baseOrFull.replace(/\/+$/, "");
    const hasEndpoint =
      /\/(send\/text|message\/text|sendText)$/i.test(clean);
    return hasEndpoint
      ? [clean]
      : [
          `${clean}/send/text`,
          `${clean}/message/text`,
          `${clean}/sendText`,
        ];
  };

  const tried: { url: string; status: number; data: any }[] = [];

  // 1) tenta na BASE configurada
  const firstBatch = normalizeCandidates(API_BASE);
  for (const url of firstBatch) {
    const { res, data } = await tryPost(url);
    tried.push({ url, status: res.status, data });
    if (res.ok) return;

    // 2) se 404, tenta fallback por header ou corpo
    if (res.status === 404) {
      const headerFallback =
        res.headers.get("x-fallback-url") || res.headers.get("X-Fallback-URL");
      const bodyFallback =
        data && typeof data === "object" && data.step === "fallback" && typeof data.url === "string"
          ? String(data.url)
          : null;

      const fb = headerFallback || bodyFallback;
      if (fb) {
        const fbBatch = normalizeCandidates(fb);
        for (const alt of fbBatch) {
          const r2 = await tryPost(alt);
          tried.push({ url: alt, status: r2.res.status, data: r2.data });
          if (r2.res.ok) return;
        }
      }
    }
  }

  // 3) falhou tudo -> erro detalhado
  const lines = tried.map(t => {
    const d = typeof t.data === "string" ? t.data : JSON.stringify(t.data);
    return `${t.status} ${t.url} -> ${d}`;
  });
  throw new Error(`Falha ao enviar (tentativas):\n${lines.join("\n")}`);
}

/* ========= Worker ========= */
async function processBatches() {
  const store = getStore();
  if (store.processing) return;
  store.processing = true;

  try {
    for (const [, batch] of store.batches) {
      if (batch.inProgress) continue;
      batch.inProgress = true;

      while (batch.jobs.length) {
        const job = batch.jobs[0]; // peek
        const wait = Math.max(0, job.scheduledAt - now());
        if (wait > 0) {
          await sleep(Math.min(wait, 1000)); // cochilo curto
          continue;
        }

        // hora de enviar
        batch.jobs.shift();
        try {
          if (job.msgRowId) {
            await supabase.from("messages").update({ status: "sending", error: null }).eq("id", job.msgRowId);
          }

          await sendViaUazapi(job.to, job.text);

          if (job.msgRowId) {
            await supabase.from("messages").update({
              status: "sent",
              error: null,
              sent_at: new Date().toISOString(),
            }).eq("id", job.msgRowId);
          }
        } catch (e: any) {
          if (job.msgRowId) {
            await supabase.from("messages").update({
              status: "error",
              error: String(e?.message || e),
            }).eq("id", job.msgRowId);
          }
        }
      }

      batch.inProgress = false;
    }
  } finally {
    store.processing = false;
  }
}

function createBatch(): Batch {
  const s = getStore();
  const id = ++s.lastId;
  const b: Batch = { id, createdAt: now(), jobs: [], inProgress: false };
  s.batches.set(id, b);
  return b;
}

/* ========= Construção das linhas + jobs ========= */
async function createRowsAndJobs(
  batchId: number,
  contacts: Contact[],
  textPool: string[],
  startAtMs?: number | null,
  cadenceDays?: number[] | null,
  listaId?: number | null,
  listaNome?: string | null
) {
  const startBase = (typeof startAtMs === "number" && startAtMs > 0 ? startAtMs : now());
  const cadence = Array.isArray(cadenceDays) ? cadenceDays : [];

  const rows: any[] = [];
  const jobs: Job[] = [];

  for (const c of contacts) {
    const numero = norm(c.numero);
    if (!numero) continue;

    const moments = [startBase, ...cadence.map(d => startBase + d * 86400000)];
    for (const when of moments) {
      for (const t of textPool) {
        const text = (t || "")
          .replaceAll("{{nome}}", String(c.nome || ""))
          .replaceAll("{{numero}}", String(c.numero || ""));

        rows.push({
          batch_id: batchId,
          lista_id: listaId ?? null,
          lista_nome: listaNome ?? null,
          numero,
          status: "queued",
          error: null,
          payload: { text },
          created_at: new Date().toISOString(),
          scheduled_at: new Date(when).toISOString(),
        });

        jobs.push({ to: numero, text, batchId, msgRowId: null, scheduledAt: when });
      }
    }
  }

  if (!rows.length) return { inserted: [], jobs: [] as Job[] };

  const { data, error } = await supabase
    .from("messages")
    .insert(rows)
    .select("id");

  if (error) throw new Error(error.message);

  let i = 0;
  for (const j of jobs) j.msgRowId = data?.[i++].id ?? null;

  return { inserted: data || [], jobs };
}

/* ========= GET (status do batch) ========= */
export async function GET(req: NextRequest) {
  const batchId = Number(req.nextUrl.searchParams.get("batchId") || 0);
  if (!batchId) return NextResponse.json({ error: "missing batchId" }, { status: 400 });

  const { data } = await supabase
    .from("messages")
    .select("status, error")
    .eq("batch_id", batchId);

  const sent   = data?.filter(r => r.status === "sent").length ?? 0;
  const failed = data?.filter(r => r.status === "error").length ?? 0;
  const queued = data?.filter(r => r.status === "queued" || r.status === "sending").length ?? 0;

  return NextResponse.json({
    ok: true,
    batchId,
    sent, failed, queued,
    inProgress: queued > 0,
    errors: (data || []).filter(r => !!(r as any).error).slice(-10),
  });
}

/* ========= POST (cria batch, agenda e dispara worker) ========= */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const {
      listaId = null,
      listaNome = null,
      textPool = [],
      contacts = [],
      cadenceDays = [],
      delayMsMin = 1000,
      delayMsMax = 5000,
      pauseEvery = 0,
      pauseDurationMs = 0,
    } = body || {};

    if (!API_BASE || !TOKEN_INSTANCIA)
      return NextResponse.json({ ok: false, error: "config_missing" }, { status: 500 });

    if (!Array.isArray(textPool) || textPool.map(s => String(s || "").trim()).filter(Boolean).length === 0)
      return NextResponse.json({ ok: false, error: "empty_templates" }, { status: 400 });

    if (!Array.isArray(contacts) || contacts.length === 0)
      return NextResponse.json({ ok: false, error: "empty_contacts" }, { status: 400 });

    // Se fora do horário, dispara a partir de 08:00 do próximo dia útil
    let startAt = now();
    if (!dentroHorario()) startAt = proxDiaUtil0800().getTime();

    const batch = createBatch();

    // cria linhas + jobs base (sem jitter/pausas)
    const { jobs } = await createRowsAndJobs(
      batch.id,
      contacts,
      textPool.map((s: string) => String(s || "").trim()).filter(Boolean),
      startAt,
      cadenceDays,
      listaId,
      listaNome
    );

    if (jobs.length === 0)
      return NextResponse.json({ ok: false, error: "no_valid_numbers" }, { status: 400 });

    // aplica jitter/pausas
    const min = Math.max(0, Math.min(delayMsMin, delayMsMax));
    const max = Math.max(delayMsMin, delayMsMax);
    const sorted = jobs.sort((a, b) => a.scheduledAt - b.scheduledAt);

    let cursor = Math.max(now(), sorted[0].scheduledAt);
    let sincePause = 0;

    for (const j of sorted) {
      const gap = rand(min, max);
      cursor += gap;
      j.scheduledAt = cursor;
      sincePause++;
      if (pauseEvery > 0 && sincePause % pauseEvery === 0) {
        cursor += Math.max(0, pauseDurationMs);
      }
    }

    // persiste scheduled_at ajustado
    for (const j of sorted) {
      if (j.msgRowId) {
        await supabase
          .from("messages")
          .update({ scheduled_at: new Date(j.scheduledAt).toISOString() })
          .eq("id", j.msgRowId);
      }
    }

    // empilha e roda worker
    batch.jobs.push(...sorted);
    processBatches().catch(() => null);

    return NextResponse.json({
      ok: true,
      batchId: batch.id,
      queued: batch.jobs.length,
      firstAt: new Date(sorted[0].scheduledAt).toISOString(),
      lastAt:  new Date(sorted.at(-1)!.scheduledAt).toISOString(),
    });
  } catch (e: any) {
    console.error("[disparos:POST:error]", e);
    return NextResponse.json({ ok: false, error: String(e?.message || e) }, { status: 500 });
  }
}
