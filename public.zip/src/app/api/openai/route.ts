import { NextResponse } from "next/server";
import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function POST(req: Request) {
  try {
    const { prompt, model } = await req.json();

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "OPENAI_API_KEY não configurada no ambiente" }, { status: 500 });
    }
    if (!prompt || !model) {
      return NextResponse.json({ error: "Parâmetros inválidos" }, { status: 400 });
    }

    // Chat Completions (modelos compatíveis)
    const completion = await client.chat.completions.create({
      model,
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
      max_tokens: 200,
    });

    const message = completion.choices?.[0]?.message?.content ?? "";
    return NextResponse.json({ message });
  } catch (err: any) {
    console.error("OPENAI ROUTE ERROR:", err?.message || err);
    return NextResponse.json({ error: "Falha ao gerar mensagem" }, { status: 500 });
  }
}
