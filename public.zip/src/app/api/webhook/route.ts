// src/app/api/uazapi/webhook/route.ts
import { NextResponse } from "next/server";
import { supabase } from "../../lib/supabase";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** ===== Helpers ===== */
const WEBHOOK_SECRET = process.env.UAZAPIGO_WEBHOOK_SECRET || "";

const ts = () => new Date().toISOString();
const onlyDigits = (n: string) => (n || "").replace(/\D/g, "");

/** Normaliza para dígitos; se não vier com 55 e tiver 10–12 dígitos, prefixa 55 */
function normalizeNumero(raw?: string | null): string | null {
  if (!raw) return null;
  const d = onlyDigits(String(raw).split("@")[0]);
  if (!d) return null;
  if (d.startsWith("55")) return d;
  if (d.length >= 10 && d.length <= 12) return "55" + d;
  return d; // deixa como está se for outro DDI
}

/** Extrai número de vários formatos possíveis enviados por provedores */
function extractNumero(body: any): string | null {
  const candidates = [
    body?.to, body?.from, body?.sender, body?.number, body?.waId, body?.remoteJid,
    body?.contact?.wa_id, body?.contact?.number, body?.message?.from, body?.data?.to, body?.data?.from,
  ].filter(Boolean);
  for (const c of candidates) {
    const n = normalizeNumero(String(c));
    if (n) return n;
  }
  return null;
}

/** Extrai ID da msg do provedor (para idempotência) */
function extractProviderId(body: any): string | null {
  return (
    body?.id ||
    body?.messageId ||
    body?.data?.id ||
    body?.data?.messageId ||
    body?.key?.id ||
    null
  ) ? String(
    body?.id ||
    body?.messageId ||
    body?.data?.id ||
    body?.data?.messageId ||
    body?.key?.id
  ) : null;
}

/** Extrai batchId se você estiver devolvendo no payload ao enviar */
function extractBatchId(body: any): number | null {
  const v = body?.batchId ?? body?.data?.batchId ?? body?.payload?.batchId;
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : null;
}

/** Retorna 1=sent 2=delivered 3=read quando houver */
function extractAck(body: any): 0 | 1 | 2 | 3 {
  const a = body?.ack ?? body?.status?.ack ?? body?.data?.ack;
  const n = Number(a);
  if (n === 1 || n === 2 || n === 3) return n as 1 | 2 | 3;
  return 0;
}

/** Diz se a mensagem veio “de mim” (enviada pela nossa conta) */
function extractFromMe(body: any): boolean {
  return !!(body?.fromMe ?? body?.data?.fromMe ?? body?.key?.fromMe);
}

/** Detecta se é resposta de cliente / texto inbound */
function detectInboundText(body: any, fromMe: boolean): boolean {
  if (fromMe) return false;
  return Boolean(
    body?.text ||
    body?.message?.text ||
    body?.content ||
    body?.message?.conversation ||
    body?.data?.message?.text
  );
}

/** Se for reply, tenta achar a msg original */
function extractReplyToId(body: any): string | null {
  return (
    body?.quotedMsgId ||
    body?.context?.id ||
    body?.message?.contextInfo?.stanzaId ||
    body?.data?.context?.id ||
    null
  ) ? String(
    body?.quotedMsgId ||
    body?.context?.id ||
    body?.message?.contextInfo?.stanzaId ||
    body?.data?.context?.id
  ) : null;
}

/** Insere um registro em message_events (auditoria), sempre */
async function auditEvent(messageId: number | null, kind: string, data: any) {
  await supabase.from("message_events").insert({
    message_id: messageId,
    kind,
    data,
    created_at: ts(),
  });
}

/** Tenta atualizar status agregado do batch quando possível */
async function maybeUpdateBatchStatus(batchId: number) {
  if (!batchId) return;
  const { data, error } = await supabase
    .from("messages")
    .select("status", { count: "exact" })
    .eq("batch_id", batchId);

  if (error || !data) return;

  let queued = 0, sending = 0, sent = 0, delivered = 0, read = 0, replied = 0, errorCount = 0;
  for (const m of data) {
    switch (m.status) {
      case "queued": queued++; break;
      case "sending": sending++; break;
      case "sent": sent++; break;
      case "delivered": delivered++; break;
      case "read": read++; break;
      case "replied": replied++; break;
      case "error": errorCount++; break;
    }
  }
  const total = (data as any[]).length;
  const progressed = sent + delivered + read + replied + errorCount;

  let status: string = "queued";
  if (replied > 0) status = "replied";
  else if (read > 0) status = "read";
  else if (delivered > 0) status = "delivered";
  else if (sent > 0) status = "sent";
  else if (sending > 0) status = "sending";
  else status = "queued";

  // done quando todos saíram de queued/sending
  if (progressed === total && total > 0) status = "done";

  await supabase.from("batches").update({
    status,
    updated_at: ts(),
  }).eq("id", batchId);
}

/** Remove número das listas quando respondeu */
async function removeFromLists(numero: string) {
  const { data: listas } = await supabase.from("listas_disparos").select("id, contatos");
  for (const lista of listas || []) {
    const contatos = Array.isArray(lista.contatos) ? lista.contatos : [];
    if (contatos.some((c: any) => onlyDigits(String(c.numero)) === numero)) {
      const filtrados = contatos.filter((c: any) => onlyDigits(String(c.numero)) !== numero);
      const nome = (contatos.find((c: any) => onlyDigits(String(c.numero)) === numero)?.nome) ?? null;
      await supabase.from("listas_disparos").update({ contatos: filtrados }).eq("id", lista.id);
      await supabase.from("contatos_removidos").insert({
        numero, nome, motivo: "respondeu", lista_id: lista.id, created_at: ts(),
      });
    }
  }
}

/** ===== Handler ===== */
export async function POST(req: Request) {
  try {
    if (WEBHOOK_SECRET) {
      const h = req.headers.get("x-webhook-secret") || "";
      if (h !== WEBHOOK_SECRET) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    }

    const raw = await req.json().catch(() => ({}));
    const events = Array.isArray(raw) ? raw : [raw];

    for (const body of events) {
      const fromMe = extractFromMe(body);
      const numero = extractNumero(body);
      const providerId = extractProviderId(body);
      const batchId = extractBatchId(body);
      const ack = extractAck(body);
      const isInboundText = detectInboundText(body, fromMe);
      const replyTo = extractReplyToId(body);

      // Auditar bruto sem vincular (pode ajudar em debugging)
      await auditEvent(null, "webhook_raw", body);

      // 1) Resposta do cliente (texto inbound)
      if (isInboundText && numero) {
        // Se foi reply a uma msg nossa, marque como replied
        if (replyTo) {
          const { data: msg } = await supabase
            .from("messages")
            .select("id, batch_id")
            .eq("provider_message_id", replyTo)
            .maybeSingle();

          if (msg?.id) {
            await supabase.from("messages").update({
              status: "replied",
              replied_at: ts(),
            }).eq("id", msg.id);
            await auditEvent(msg.id, "reply", body);
            if (msg.batch_id) await maybeUpdateBatchStatus(msg.batch_id);
            await removeFromLists(numero);
            continue;
          }
        }

        // Se não há replyTo, registre como inbound "solta" (nova conversa)
        const { data: created, error } = await supabase.from("messages").insert({
          batch_id: batchId ?? null,
          numero,
          status: "replied",
          replied_at: ts(),
          direction: "inbound",
          provider_message_id: providerId ?? null,
          payload: { meta: { source: "webhook-inbound" }, raw: body },
          created_at: ts(),
        }).select("id, batch_id").single();

        if (!error && created?.id) {
          await auditEvent(created.id, "inbound", body);
          if (created.batch_id) await maybeUpdateBatchStatus(created.batch_id);
          await removeFromLists(numero);
        }
        continue;
      }

      // 2) Eventos de msg “minha” (acks / erro etc.)
      if (fromMe && providerId) {
        const { data: msg } = await supabase
          .from("messages")
          .select("id, batch_id, status")
          .eq("provider_message_id", providerId)
          .maybeSingle();

        if (!msg?.id) {
          // sem correspondência — opcional: criar esqueleto
          // útil quando o provedor manda ack antes do insert local
          const { data: created } = await supabase.from("messages").insert({
            batch_id: batchId ?? null,
            numero: numero ?? null,
            status: "sending",
            direction: "outbound",
            provider_message_id: providerId,
            payload: { meta: { source: "webhook-ack" }, raw: body },
            created_at: ts(),
          }).select("id, batch_id").single();

          if (created?.id) {
            await auditEvent(created.id, "ack_skipped_seed", body);
            if (created.batch_id) await maybeUpdateBatchStatus(created.batch_id);
          }
          continue;
        }

        // Atualiza conforme ack/erro
        if (ack === 1) {
          await supabase.from("messages").update({ status: "sent", sent_at: ts() }).eq("id", msg.id);
          await auditEvent(msg.id, "ack", body);
        } else if (ack === 2) {
          await supabase.from("messages").update({ status: "delivered", delivered_at: ts() }).eq("id", msg.id);
          await auditEvent(msg.id, "delivered", body);
        } else if (ack === 3) {
          await supabase.from("messages").update({ status: "read", read_at: ts() }).eq("id", msg.id);
          await auditEvent(msg.id, "read", body);
        } else if (body?.type === "message_failed" || body?.status === "error" || body?.error) {
          await supabase.from("messages").update({
            status: "error",
            error: body?.error?.message || body?.error || "send failed",
          }).eq("id", msg.id);
          await auditEvent(msg.id, "error", body);
        } else {
          // sem ack numérico — audita genérico
          await auditEvent(msg.id, "provider_event", body);
        }

        if (msg.batch_id) await maybeUpdateBatchStatus(msg.batch_id);
        continue;
      }

      // 3) Sem número/sem providerId — audita e segue
      await auditEvent(null, "ignored", body);
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    console.error("💥 WEBHOOK ERRO:", e);
    return NextResponse.json({ error: String(e?.message || e) }, { status: 500 });
  }
}
