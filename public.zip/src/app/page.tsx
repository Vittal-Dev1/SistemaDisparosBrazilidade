// src/app/login/page.tsx
"use client";
import { useState } from "react";

type LoginPageProps = {
  onLogin: () => void;
};

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setErr(null);
    try {
      // Exemplo: ajuste para sua API real de login
      const res = await fetch("/api/login", { method: "POST" });
      if (!res.ok) throw new Error("Falha no login");
      const { token } = await res.json();
      localStorage.setItem("token", token);
      onLogin();
    } catch (e: any) {
      setErr(e.message || "Erro ao entrar");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="p-6 max-w-sm mx-auto">
      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-md bg-zinc-800 text-white py-2"
      >
        {loading ? "Entrando..." : "Entrar"}
      </button>
      {err && <p className="mt-2 text-sm text-red-500">{err}</p>}
    </form>
  );
}
