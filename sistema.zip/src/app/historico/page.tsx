"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Clock, RefreshCw, Search, ChevronRight, X, Loader2,
  Calendar as CalendarIcon, Download
} from "lucide-react";
import { LineChart, Line, ResponsiveContainer } from "recharts";

/* ================== Tipos ================== */
type Historico = {
  id: number;                // batchId
  lista_id: number | null;
  total_enviado: number;     // total previsto
  data: string;              // ISO
  status?: string;           // queued|sending|sent|delivered|read|replied|error|done
  instance?: string | null;
};

export type LiveItem = {
  id: number;
  numero: string;
  status: "queued"|"sending"|"sent"|"delivered"|"read"|"replied"|"error";
  error?: string | null;
  sent_at?: string | null;
  delivered_at?: string | null;
  read_at?: string | null;
  replied_at?: string | null;
};

/* ================== Utils ================== */
const cn = (...xs: (string|false|undefined|null)[]) => xs.filter(Boolean).join(" ");
const isNumStr = (v: unknown) => typeof v === "string" && /^\d+$/.test(v);

function toISO(value: string | number | Date): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "number") {
    const ms = value < 1_000_000_000_000 ? value * 1000 : value; // sec→ms
    return new Date(ms).toISOString();
  }
  if (isNumStr(value)) {
    const n = Number(value);
    const ms = n < 1_000_000_000_000 ? n * 1000 : n;
    return new Date(ms).toISOString();
  }
  const d = new Date(value);
  return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}

const dateNum = (isoLike: string) => {
  const n = Date.parse(isoLike);
  return Number.isFinite(n) ? n : Date.now();
};

function StatusBadge({ value }: { value?: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    queued:   { label: "Na fila",   cls: "bg-zinc-700/40 text-zinc-200 ring-1 ring-zinc-500/30" },
    sending:  { label: "Enviando…", cls: "bg-indigo-500/15 text-indigo-300 ring-1 ring-indigo-400/20" },
    sent:     { label: "Enviada",   cls: "bg-blue-500/15 text-blue-300 ring-1 ring-blue-400/20" },
    delivered:{ label: "Entregue",  cls: "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/20" },
    read:     { label: "Lida",      cls: "bg-violet-500/15 text-violet-300 ring-1 ring-violet-400/20" },
    replied:  { label: "Respondida",cls: "bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/20" },
    error:    { label: "Erro",      cls: "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/20" },
    done:     { label: "Concluída", cls: "bg-emerald-600/15 text-emerald-300 ring-1 ring-emerald-500/25" },
  };
  const info = (value && map[value]) || map.queued;
  return <span className={cn("inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium", info.cls)}>{info.label}</span>;
}

function sumByStatus(items: LiveItem[]) {
  const m = { queued:0, sending:0, sent:0, delivered:0, read:0, replied:0, error:0 };
  for (const it of items) (m as any)[it.status] += 1;
  return m;
}

/* ===== Normalizador (flexível com vários backends) ===== */
function normalizeHistoricoRow(raw: any): Historico | null {
  if (!raw) return null;
  const id = Number(raw.id ?? raw.batch_id ?? raw.batchId);
  if (!Number.isFinite(id)) return null;

  const lista_id =
    raw.lista_id != null ? Number(raw.lista_id)
    : raw.list_id != null ? Number(raw.list_id)
    : null;

  const total_enviado =
    Number(raw.total_enviado ?? raw.total ?? raw.count ?? raw.expected ?? 0);

  const dataISO = toISO(
    raw.data ?? raw.created_at ?? raw.createdAt ?? raw.first_at ?? raw.scheduled_at ?? Date.now()
  );

  const status = String(raw.status ?? raw.final_status ?? raw.state ?? "").trim() || undefined;
  const instance = raw.instance ?? raw.instance_name ?? null;

  return { id, lista_id, total_enviado, data: dataISO, status, instance };
}

/* ================== Página ================== */
export default function HistoricoPage() {
  const [items, setItems] = useState<Historico[]>([]);
  const [loading, setLoading] = useState(true);

  // filtros (com debounce)
  const [qRaw, setQRaw] = useState("");
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("");
  const [from, setFrom] = useState<string>("");
  const [to, setTo] = useState<string>("");

  useEffect(() => {
    const t = setTimeout(() => setQ(qRaw.trim()), 300);
    return () => clearTimeout(t);
  }, [qRaw]);

  // cache de nomes de lista
  const [listaNames, setListaNames] = useState<Map<number, string>>(new Map());

  // detalhe
  const [selected, setSelected] = useState<Historico | null>(null);
  const [live, setLive] = useState<LiveItem[]>([]);
  const [liveError, setLiveError] = useState("");
  const esRef = useRef<EventSource | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  /* ------- fetch histórico (memoizado) ------- */
  const fetchHistorico = useCallback(async () => {
    setLoading(true);
    const ctrl = new AbortController();
    try {
      const qs = new URLSearchParams();
      qs.set("order", "desc");
      qs.set("limit", "300");
      if (q) qs.set("q", q);
      if (status) qs.set("status", status);
      if (from) qs.set("from", from);
      if (to) qs.set("to", to);

      const res = await fetch(`/api/historico?${qs.toString()}`, {
        cache: "no-store",
        signal: ctrl.signal,
      });

      const text = await res.text();
      let json: any;
      try { json = JSON.parse(text); } catch { json = []; } // evita “<!doctype …”

      const arrSrc = Array.isArray(json?.items) ? json.items : Array.isArray(json) ? json : [];
      const arr = (arrSrc.map(normalizeHistoricoRow).filter(Boolean) as Historico[])
        .sort((a, b) => {
          const da = dateNum(a.data), db = dateNum(b.data);
          if (db !== da) return db - da;
          return (b.id ?? 0) - (a.id ?? 0);
        });

      setItems(arr);

      // nomes das listas
      const need = Array.from(new Set(arr.map(i => i.lista_id).filter(Boolean))) as number[];
      await Promise.all(need.map(async (id) => {
        if (listaNames.has(id)) return;
        try {
          const r = await fetch(`/api/listas/${id}`, { cache: "no-store" });
          const t = await r.text();
          const j = JSON.parse(t);
          if (j?.id && j?.nome) setListaNames(prev => new Map(prev).set(j.id, j.nome));
        } catch { /* ignore */ }
      }));
    } finally {
      setLoading(false);
    }
    return () => ctrl.abort();
  }, [q, status, from, to, listaNames]);

  useEffect(() => { fetchHistorico(); }, [fetchHistorico]);

  // auto-refresh 15s
  useEffect(() => {
    const t = setInterval(fetchHistorico, 15000);
    return () => clearInterval(t);
  }, [fetchHistorico]);

  // refresh ao focar
  useEffect(() => {
    const onVis = () => { if (document.visibilityState === "visible") fetchHistorico(); };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [fetchHistorico]);

  // “ping” via localStorage
  useEffect(() => {
    const onStorage = (e: StorageEvent) => { if (e.key === "histRefresh") fetchHistorico(); };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [fetchHistorico]);

  /* ------- Drawer: Live (SSE + fallback) ------- */
  useEffect(() => {
    // limpar
    if (!selected) {
      if (esRef.current) { esRef.current.close(); esRef.current = null; }
      if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
      setLive([]); setLiveError("");
      return;
    }
    const id = selected.id;

    // polling
    const poll = async () => {
      try {
        const r = await fetch(`/api/disparos/items?batchId=${id}`, { cache: "no-store" });
        const t = await r.text();
        const j = (() => { try { return JSON.parse(t); } catch { return []; } })();
        const arr: LiveItem[] = Array.isArray(j?.items) ? j.items : Array.isArray(j) ? j : [];
        setLive(arr);
        setLiveError("");
      } catch {
        setLiveError("Falha ao atualizar itens.");
      }
    };
    poll();
    pollRef.current = setInterval(poll, 2000);

    // SSE (opcional)
    try {
      const es = new EventSource(`/api/disparos/stream?batchId=${id}`);
      esRef.current = es;
      es.addEventListener("snapshot", (ev: MessageEvent) => {
        try {
          const data = JSON.parse(ev.data);
          if (Array.isArray(data?.items)) setLive(data.items);
          setLiveError("");
        } catch { /* ignore */ }
      });
      es.addEventListener("error", () => setLiveError("Stream indisponível — usando atualização automática."));
    } catch { /* ignore */ }

    return () => {
      if (esRef.current) { esRef.current.close(); esRef.current = null; }
      if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
    };
  }, [selected?.id]);

  /* ------- filtros locais ------- */
  const filtered = useMemo(() => {
    const base = items.slice();
    return base.filter((it) => {
      const hay = [
        `#${it.id}`,
        it.lista_id ?? "",
        listaNames.get(it.lista_id ?? -1) ?? "",
        it.instance ?? "",
        it.status ?? "",
      ].join(" ").toLowerCase();

      const okQ = q ? hay.includes(q.toLowerCase()) : true;
      const d = dateNum(it.data);
      const okFrom = from ? d >= new Date(from).getTime() : true;
      const okTo = to ? d <= new Date(to).getTime() + 86_400_000 - 1 : true;
      const okS = status ? it.status === status : true;
      return okQ && okFrom && okTo && okS;
    });
  }, [items, q, status, from, to, listaNames]);

  /* ------- KPIs ------- */
  const kpis = useMemo(() => {
    const total = filtered.length;
    const enviadasPrev = filtered.reduce((acc, i) => acc + (i.total_enviado || 0), 0);
    const concluidas = filtered.filter(i => ["done","replied"].includes(i.status || "")).length;
    const erros = filtered.filter(i => i.status === "error").length;
    return { total, enviadasPrev, concluidas, erros };
  }, [filtered]);

  /* ================== UI ================== */
  const StatCard = ({ title, value }: { title: string; value: string }) => (
    <div className="rounded-2xl border border-zinc-800/70 bg-zinc-900/50 p-4">
      <p className="text-xs text-zinc-400">{title}</p>
      <h3 className="mt-1 text-xl font-semibold text-white">{value}</h3>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-950 to-black text-white">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-6 pt-10 pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-2xl bg-indigo-600/25 ring-1 ring-indigo-400/30 flex items-center justify-center">
              <Clock className="h-5 w-5 text-indigo-300" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold">Histórico de Disparos</h1>
              <p className="text-sm text-zinc-400">Acompanhe campanhas, status e resultados.</p>
            </div>
          </div>
          <button
            onClick={fetchHistorico}
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-800/80 bg-zinc-900/40 px-3 py-2 text-sm hover:bg-zinc-900"
          >
            <RefreshCw className="h-4 w-4" /> Atualizar
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Campanhas" value={String(kpis.total)} />
        <StatCard title="Mensagens prev." value={String(kpis.enviadasPrev)} />
        <StatCard title="Concluídas" value={String(kpis.concluidas)} />
        <StatCard title="Erros" value={String(kpis.erros)} />
      </div>

      {/* Filtros */}
      <div className="max-w-7xl mx-auto px-6 mt-6">
        <div className="rounded-2xl border border-zinc-800/70 bg-zinc-900/50 p-4">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
            <div className="md:col-span-2">
              <label className="text-xs text-zinc-400">Buscar</label>
              <div className="mt-1 flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2">
                <Search className="h-4 w-4 text-zinc-500" />
                <input
                  value={qRaw}
                  onChange={(e)=>setQRaw(e.target.value)}
                  placeholder="ID, Lista, Instância, Status…"
                  className="bg-transparent outline-none text-sm flex-1"
                />
              </div>
            </div>
            <div>
              <label className="text-xs text-zinc-400">Status</label>
              <select
                value={status}
                onChange={(e)=>setStatus(e.target.value)}
                className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm outline-none"
              >
                <option value="">Todos</option>
                {['queued','sending','sent','delivered','read','replied','done','error'].map(s=> <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-zinc-400">De</label>
              <div className="mt-1 flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2">
                <CalendarIcon className="h-4 w-4 text-zinc-500" />
                <input type="date" value={from} onChange={(e)=>setFrom(e.target.value)} className="bg-transparent outline-none text-sm flex-1" />
              </div>
            </div>
            <div>
              <label className="text-xs text-zinc-400">Até</label>
              <div className="mt-1 flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2">
                <CalendarIcon className="h-4 w-4 text-zinc-500" />
                <input type="date" value={to} onChange={(e)=>setTo(e.target.value)} className="bg-transparent outline-none text-sm flex-1" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabela */}
      <div className="max-w-7xl mx-auto px-6 mt-6">
        <div className="rounded-3xl border border-zinc-800/70 overflow-hidden bg-zinc-900/40">
          <table className="w-full text-sm">
            <thead className="bg-zinc-900/60">
              <tr>
                <th className="text-left px-4 py-3">Batch</th>
                <th className="text-left px-4 py-3">Lista</th>
                <th className="text-left px-4 py-3">Total</th>
                <th className="text-left px-4 py-3">Instância</th>
                <th className="text-left px-4 py-3">Data</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="text-right px-4 py-3"> </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-zinc-400"><Loader2 className="inline h-4 w-4 animate-spin mr-2"/>Carregando…</td></tr>
              ) : filtered.length ? (
                filtered.map((h) => {
                  const d = new Date(h.data);
                  const listName = h.lista_id ? (listaNames.get(h.lista_id) ?? `#${h.lista_id}`) : "—";
                  return (
                    <tr key={h.id} className="odd:bg-zinc-900/30">
                      <td className="px-4 py-3 font-medium">#{h.id}</td>
                      <td className="px-4 py-3">{listName}</td>
                      <td className="px-4 py-3">{h.total_enviado}</td>
                      <td className="px-4 py-3">{h.instance ?? "—"}</td>
                      <td className="px-4 py-3">{isNaN(d.getTime()) ? "—" : d.toLocaleString()}</td>
                      <td className="px-4 py-3"><StatusBadge value={h.status} /></td>
                      <td className="px-4 py-3 text-right">
                        <button onClick={() => setSelected(h)} className="inline-flex items-center gap-1 text-indigo-400 hover:text-indigo-200">
                          Ver detalhes <ChevronRight className="h-4 w-4"/>
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-zinc-400">Nenhum registro.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drawer de detalhes */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
            onClick={() => setSelected(null)}
          >
            <motion.aside
              initial={{ x: 420 }} animate={{ x: 0 }} exit={{ x: 420 }}
              transition={{ type: "spring", stiffness: 280, damping: 32 }}
              className="absolute right-0 top-0 h-full w-full max-w-xl bg-zinc-950 border-l border-zinc-800 p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold">Batch #{selected.id}</h3>
                  <p className="text-xs text-zinc-400">
                    Lista {selected.lista_id ? (listaNames.get(selected.lista_id) ?? `#${selected.lista_id}`) : "—"}
                    {" • "}
                    {new Date(selected.data).toLocaleString()}
                  </p>
                </div>
                <button onClick={() => setSelected(null)} className="text-zinc-400 hover:text-zinc-200"><X className="h-5 w-5"/></button>
              </div>

              {/* Resumo */}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="rounded-xl border border-zinc-800/60 p-3">
                  <p className="text-xs text-zinc-400">Total previsto</p>
                  <p className="text-xl font-semibold">{selected.total_enviado}</p>
                </div>
                <div className="rounded-xl border border-zinc-800/60 p-3">
                  <p className="text-xs text-zinc-400">Status</p>
                  <div className="mt-1"><StatusBadge value={selected.status}/></div>
                </div>
              </div>

              {/* KPIs live */}
              <div className="grid grid-cols-4 gap-3 mt-4">
                {(() => {
                  const s = sumByStatus(live);
                  const Box = ({t,v}:{t:string;v:number}) => (
                    <div className="rounded-xl border border-zinc-800/60 p-3">
                      <p className="text-xs text-zinc-400">{t}</p>
                      <p className="text-lg font-semibold">{v}</p>
                    </div>
                  );
                  return (
                    <>
                      <Box t="Sent" v={s.sent} />
                      <Box t="Delivered" v={s.delivered} />
                      <Box t="Read" v={s.read} />
                      <Box t="Respondidas" v={s.replied} />
                    </>
                  );
                })()}
              </div>

              {/* Gráfico simples */}
              <div className="rounded-2xl border border-zinc-800/60 mt-4 p-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-zinc-400">Andamento (ao vivo)</p>
                  <button
                    className="text-xs inline-flex items-center gap-1 rounded-lg border border-zinc-800 px-2 py-1 hover:bg-zinc-900"
                    onClick={()=>{
                      const rows = live.map((x,i)=>({i:i+1, numero:x.numero, status:x.status, erro:x.error||""}));
                      const csv = ["#;numero;status;erro", ...rows.map(r=>`${r.i};${r.numero};${r.status};${(r.erro||"").replaceAll?.(";"," ").replaceAll?.("\n"," ")}`)].join("\n");
                      const blob = new Blob([csv], {type:"text/csv;charset=utf-8"});
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement("a");
                      a.href = url; a.download = `batch_${selected.id}.csv`; a.click();
                      URL.revokeObjectURL(url);
                    }}
                  >
                    <Download className="h-3.5 w-3.5"/> Exportar CSV
                  </button>
                </div>
                <div className="h-24 mt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={live.map((x, i) => ({
                      i,
                      v: (x.status==='sent'||x.status==='delivered'||x.status==='read'||x.status==='replied') ? 1 : (x.status==='error'? -1 : 0)
                    }))}>
                      <Line type="monotone" dataKey="v" dot={false} strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                {liveError && (
                  <div className="mt-2 text-xs text-rose-300 bg-rose-500/10 border border-rose-400/30 rounded-md px-2 py-1">
                    {liveError}
                  </div>
                )}
              </div>

              {/* Lista live */}
              <div className="rounded-2xl border border-zinc-800/60 mt-4 overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-zinc-900/60">
                    <tr>
                      <th className="text-left px-3 py-2">#</th>
                      <th className="text-left px-3 py-2">Número</th>
                      <th className="text-left px-3 py-2">Status</th>
                      <th className="text-left px-3 py-2">Erro</th>
                    </tr>
                  </thead>
                  <tbody>
                    {live.length ? live.map((it, idx) => (
                      <tr key={`${it.id}-${idx}`} className="odd:bg-zinc-900/30">
                        <td className="px-3 py-2">{idx + 1}</td>
                        <td className="px-3 py-2">{it.numero}</td>
                        <td className="px-3 py-2"><StatusBadge value={it.status} /></td>
                        <td className="px-3 py-2 text-rose-400 text-xs truncate max-w-[220px]">{it.error || ""}</td>
                      </tr>
                    )) : (
                      <tr><td colSpan={4} className="px-3 py-8 text-center text-zinc-400">Aguardando eventos…</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="h-8" />
    </div>
  );
}
