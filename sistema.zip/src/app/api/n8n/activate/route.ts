export const dynamic = "force-dynamic";


export async function POST(req: Request) {
try {
const body = await req.json();


// TESTE simples: dispara payload de exemplo para o n8n
if (body?.test && body?.n8nWebhookUrl) {
const r = await fetch(body.n8nWebhookUrl, {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify({
type: "test",
provider: "manual",
message: "Hello n8n!",
timestamp: Date.now(),
}),
});
if (!r.ok) {
return new Response(JSON.stringify({ error: `n8n respondeu ${r.status}` }), { status: 500 });
}
return new Response(JSON.stringify({ ok: true, message: "Teste enviado ao n8n" }), { status: 200 });
}


const {
provider,
providerBaseUrl,
providerToken,
mode,
n8nWebhookUrl,
proxySecret,
} = body || {};


// TODO: persista em DB se necessário.
// Exemplo (Supabase): await supabase.from('integracoes').upsert({...})


// GANCHO: configurar webhook no provedor (exemplos genéricos)
// Evolution (exemplo ilustrativo — ajuste para sua API real):
// await fetch(`${providerBaseUrl}/webhook`, {
// method: 'POST',
// headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${providerToken}` },
// body: JSON.stringify({ url: mode === 'proxy' ? `${origin}/api/webhooks/inbound` : n8nWebhookUrl })
// })


// Uazapi (exemplo ilustrativo — ajuste para sua API real):
// await fetch(`${providerBaseUrl}/instance/update-webhook`, {
// method: 'POST',
// headers: { 'Content-Type': 'application/json', 'apikey': providerToken },
// body: JSON.stringify({ webhook: mode === 'proxy' ? `${origin}/api/webhooks/inbound` : n8nWebhookUrl })
// })


return new Response(
JSON.stringify({ ok: true, message: "Configuração salva. Ajuste o 'set webhook' no provedor conforme sua API." }),
{ status: 200 }
);
} catch (e: any) {
return new Response(JSON.stringify({ error: e.message || "Erro desconhecido" }), { status: 500 });
}
}