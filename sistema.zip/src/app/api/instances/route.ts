// src/app/api/instances/route.ts
import { NextResponse } from "next/server";

export const runtime = "nodejs";

const API_URL = process.env.UAZAPIGO_API_URL || "";
const ADMIN_TOKEN = process.env.UAZAPIGO_ADMIN_TOKEN || "";

type Normalized = {
  id: string;
  name: string;
  number: string;
  photo: string;
  connected: boolean;
  status: string;
  device: string;
  lastSeen: string | null;
};

function okEnv() {
  return !!API_URL && !!ADMIN_TOKEN;
}

async function safeJson(res: Response) {
  try {
    const txt = await res.text();
    if (!txt) return {};
    try {
      return JSON.parse(txt);
    } catch {
      return { raw: txt };
    }
  } catch {
    return {};
  }
}

function normalize(raw: any): Normalized | null {
  if (!raw) return null;

  const id =
    String(
      raw?.id ??
        raw?.instance?.id ??
        raw?.instanceId ??
        raw?.uuid ??
        raw?.name ??
        ""
    ) || Math.random().toString(36).slice(2);

  const name =
    String(
      raw?.name ??
        raw?.instance?.name ??
        raw?.instanceName ??
        raw?.sessionName ??
        raw?.deviceName ??
        id
    ) || "(sem nome)";

  const number =
    String(
      raw?.number ??
        raw?.instance?.number ??
        raw?.phone ??
        raw?.me?.id ??
        raw?.me?.user ??
        raw?.jid ??
        ""
    ) || "";

  // foto: mantém absoluta/data:, ou resolve relativa; se vazio, deixa ""
  const photoCandidate =
    raw?.photo ||
    raw?.profilePic ||
    raw?.profile_picture_url ||
    raw?.avatar ||
    raw?.profilePicUrl ||
    raw?.me?.photo ||
    raw?.me?.profilePicUrl ||
    raw?.instance?.photo ||
    "";

  let photo = "";
  if (typeof photoCandidate === "string") {
    const p = photoCandidate.trim();
    if (p.startsWith("data:image/")) {
      photo = p;
    } else if (/^https?:\/\//i.test(p)) {
      photo = p;
    } else if (p) {
      const base = API_URL.replace(/\/+$/, "");
      const rel = p.replace(/^\/+/, "");
      photo = `${base}/${rel}`;
    }
  }

  const connected =
    Boolean(
      raw?.connected ??
        raw?.isConnected ??
        (raw?.status === "connected") ??
        (raw?.state === "CONNECTED") ??
        raw?.instance?.connected
    ) || false;

  const status =
    String(
      raw?.status ??
        raw?.state ??
        raw?.connectionStatus ??
        (connected ? "connected" : "disconnected")
    ) || (connected ? "connected" : "disconnected");

  const device =
    String(
      raw?.device ??
        raw?.platform ??
        raw?.me?.platform ??
        raw?.instance?.device ??
        ""
    ) || "—";

  const lastSeen =
    (raw?.lastSeen ??
      raw?.lastOnline ??
      raw?.instance?.lastSeen ??
      null) || null;

  return {
    id,
    name,
    number,
    photo,
    connected,
    status,
    device,
    lastSeen: lastSeen ? new Date(lastSeen).toISOString() : null,
  };
}

export async function GET() {
  try {
    if (!okEnv()) {
      return NextResponse.json(
        { items: [], error: "UAZAPIGO_API_URL ou UAZAPIGO_ADMIN_TOKEN não configurados" },
        { status: 200 }
      );
    }

    const attempts = [
      `${API_URL}/instance/all`,
      `${API_URL}/instances`,
      `${API_URL}/instance/list`,
    ];

    let data: any = null;
    for (const url of attempts) {
      try {
        const res = await fetch(url, {
          headers: { admintoken: ADMIN_TOKEN, Accept: "application/json" },
          cache: "no-store",
        });
        if (!res.ok) continue;
        const json = await safeJson(res);
        const list =
          (Array.isArray(json) && json) ||
          json.instances ||
          json.data ||
          json.list ||
          json.items ||
          [];
        if (Array.isArray(list)) {
          data = list;
          break;
        }
      } catch {
        // tenta próximo
      }
    }

    const items = Array.isArray(data)
      ? (data.map(normalize).filter(Boolean) as Normalized[])
      : [];

    return NextResponse.json({ items }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { items: [], error: e?.message || "Falha ao obter instâncias" },
      { status: 200 }
    );
  }
}
