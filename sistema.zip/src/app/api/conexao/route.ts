import { NextResponse } from "next/server";

/** ===== Config ===== */
const API_URL = process.env.UAZAPIGO_API_URL || "https://vittalflow.uazapi.com";
const ADMIN_TOKEN = process.env.UAZAPIGO_ADMIN_TOKEN!;
const DEFAULT_INSTANCE = (process.env.UAZAPIGO_INSTANCE_KEY || "disparos").trim();

/** ===== Utils ===== */
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function asJson(res: Response) {
  const txt = await res.text();
  if (!txt) return {};
  try { return JSON.parse(txt); } catch { return { raw: txt }; }
}

function adminHeaders(extra?: HeadersInit): HeadersInit {
  return { Accept: "application/json", admintoken: ADMIN_TOKEN, ...(extra || {}) };
}

function tokenHeaders(token: string, extra?: HeadersInit): HeadersInit {
  return { Accept: "application/json", token, ...(extra || {}) };
}

async function httpAdmin(path: string, init?: RequestInit) {
  const url = path.startsWith("http") ? path : `${API_URL}${path}`;
  return fetch(url, { ...init, headers: adminHeaders(init?.headers), cache: "no-store" });
}
async function httpToken(path: string, token: string, init?: RequestInit) {
  const url = path.startsWith("http") ? path : `${API_URL}${path}`;
  return fetch(url, { ...init, headers: tokenHeaders(token, init?.headers), cache: "no-store" });
}

/** ===== Descoberta do token da instância por nome =====
 * GET /instance/all (admintoken) -> achar registro cujo "name" bate com o nome pedido.
 */
async function findInstanceTokenByName(name: string): Promise<string | null> {
  const res = await httpAdmin("/instance/all");
  const data = await asJson(res);
  const list: any[] = Array.isArray(data) ? data : (data?.instances ?? data?.data ?? []);
  if (!Array.isArray(list)) return null;
  const norm = (s: string) => s?.trim().toLowerCase();
  const item = list.find(i => norm(String(i?.name)) === norm(name));
  const token: string | undefined = item?.token || item?.instance?.token;
  return (typeof token === "string" && token.length > 10) ? token : null;
}

/** ===== Criação de instância =====
 * POST /instance/init (admintoken) — retorna o token no payload.
 */
async function createInstance(instance: string) {
  const res = await httpAdmin("/instance/init", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: instance }),
  });
  const data = await asJson(res);
  return { ok: res.ok, status: res.status, data };
}

/** ===== Status (GET /instance/status com header token) ===== */
async function getStatus(token: string) {
  const res = await httpToken("/instance/status", token, { method: "GET" });
  const data = await asJson(res);
  return { ok: res.ok, status: res.status, data };
}

/** ===== Conectar (POST /instance/connect com header token)
 * A doc indica que o QR atualizado vem pelo /instance/status durante "connecting".
 */
async function postConnect(token: string, phone?: string) {
  const body = phone ? { phone } : {}; // se quiser pareamento por código, passe "phone"
  const res = await httpToken("/instance/connect", token, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await asJson(res);
  return { ok: res.ok, status: res.status, data };
}

/** ===== Fluxo: conectar e obter QR ===== */
async function connectAndFetchQR(instanceName: string) {
  // 1) pegar token
  let token = await findInstanceTokenByName(instanceName);
  if (!token) {
    const created = await createInstance(instanceName); // /instance/init
    if (!created.ok) return { status: created.status, body: { error: "Falha ao criar instância", detail: created.data } };
    // alguns servidores levam um tempinho pra aparecer no /instance/all
    await sleep(400);
    token = await findInstanceTokenByName(instanceName);
    if (!token) return { status: 404, body: { error: `Token da instância "${instanceName}" não encontrado após criação.` } };
  }

  // 2) iniciar conexão — se já estiver "connecting", o backend deve responder 200/409 etc. Não interrompe o fluxo.
  await postConnect(token);

  // 3) poll de status procurando qrcode
  for (let i = 0; i < 12; i++) {
    await sleep(1000);
    const st = await getStatus(token);
    if (!st.ok && i > 6) return { status: st.status, body: st.data };

    const d = st.data || {};
    // a spec define o modelo "Instance" com campo qrcode; o /status diz que retorna QR atualizado
    // Tentamos várias formas comuns:
    const qr =
      d?.instance?.qrcode ||
      d?.qrcode ||
      d?.status?.qrcode ||
      d?.instance?.qrCode ||
      d?.qrCode ||
      d?.base64;

    if (typeof qr === "string" && qr.length > 20) {
      const dataUrl = qr.startsWith("data:image") ? qr : `data:image/png;base64,${qr}`;
      return { status: 200, body: { qrCode: dataUrl, origin: "status" } };
    }

    // também trazemos um resumo de status pro front
    const state =
      d?.instance?.status ||
      (d?.status?.connected ? "connected" : d?.status ? "connecting" : undefined);

    if (state === "connected") {
      return { status: 200, body: { message: "Já está conectado", connected: true } };
    }
  }

  return { status: 504, body: { error: "QR não disponível no momento (timeout em /instance/status)" } };
}

/** ===== Handler ===== */
export async function GET(req: Request) {
  if (!ADMIN_TOKEN) {
    return NextResponse.json({ error: "UAZAPIGO_ADMIN_TOKEN ausente." }, { status: 500 });
  }

  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");
  const instance = (searchParams.get("instance") || DEFAULT_INSTANCE).trim();

  try {
    switch (action) {
      case "list": {
        const res = await httpAdmin("/instance/all");
        const data = await asJson(res);
        return NextResponse.json(data, { status: res.status });
      }

      case "create": {
        // idempotente: se já existir, não recria
        const already = await findInstanceTokenByName(instance);
        if (already) return NextResponse.json({ message: "Instância já existe", instance }, { status: 200 });
        const { status, data } = await createInstance(instance);
        return NextResponse.json(data, { status });
      }

      case "status": {
        const token = await findInstanceTokenByName(instance);
        if (!token) return NextResponse.json({ error: `Token da instância "${instance}" não encontrado.` }, { status: 404 });
        const r = await getStatus(token);
        return NextResponse.json(r.data, { status: r.status });
      }

      case "qr": {
        const r = await connectAndFetchQR(instance);
        return NextResponse.json(r.body, { status: r.status });
      }

      case "token": {
        const token = await findInstanceTokenByName(instance);
        return NextResponse.json(
          token ? { instance, tokenFound: true } : { instance, tokenFound: false },
          { status: token ? 200 : 404 }
        );
      }

      default:
        return NextResponse.json({ error: "Ação inválida" }, { status: 400 });
    }
  } catch (e) {
    console.error("💥 Erro interno conexão:", e);
    return NextResponse.json({ error: "Erro interno no servidor" }, { status: 500 });
  }
}
