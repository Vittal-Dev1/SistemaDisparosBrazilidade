// ==================================================================
// API Route (app/api/webhooks/inbound/route.ts)
// Proxy que recebe eventos do provedor e encaminha para o n8n
// - Validação por segredo opcional (X-Webhook-Secret)
// - Normalização do payload de entrada (tentando padronizar)
// - Enriquecimento com metadados (reply_to, batchId, listaId, etc.)
// - Encaminha ao n8n e, se houver decisão de resposta, envia via provedor
// ==================================================================

export const dynamic = "force-dynamic";

// ==== Config via ENV (ajuste conforme seu deploy) ====
const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL || "https://seu-n8n.com/webhook/entrada-whatsapp";
const PROXY_SECRET = process.env.WEBHOOK_PROXY_SECRET || ""; // se vazio, não valida

// Credenciais do provedor para enviar respostas
const PROVIDER_TYPE = (process.env.PROVIDER_TYPE || "evolution").toLowerCase() as
  | "evolution"
  | "uazapi"
  | "outro";
const PROVIDER_BASE_URL = process.env.PROVIDER_BASE_URL || "https://seu-provedor.com";
const PROVIDER_TOKEN = process.env.PROVIDER_TOKEN || ""; // Bearer ou apikey, conforme seu provedor

// Se quiser que este endpoint aguarde a decisão do n8n e REENVIE a resposta ao usuário
// (modo "sync") mantenha como true. Se preferir que o n8n responda por conta própria (modo "async"), use false.
const FORWARD_AND_REPLY_SYNC = (process.env.FORWARD_AND_REPLY_SYNC || "true").toLowerCase() === "true";

// ==== Tipos ====
export type Normalized = {
  provider?: string;
  instance?: string;
  from?: string; // msisdn de quem enviou
  to?: string;   // sua instância / destinatário
  text?: string;
  timestamp?: number;
  messageId?: string;
  isGroup?: boolean;
  reply_to?: string | null; // id da msg original (se a atual é reply)
  raw: any; // payload bruto para auditoria
};

// Resposta esperada do n8n (contrato sugerido)
// Você pode retornar só { replyText } que já funciona.
export type N8nDecision =
  | { action?: "none"; reason?: string }
  | { action?: "reply"; replyText: string; mediaUrl?: string; quoted?: boolean }
  | { replyText?: string; mediaUrl?: string; quoted?: boolean }; // retrocompat

// ==== Handlers HTTP ====
export async function GET() {
  return new Response("OK", { status: 200 });
}

export async function POST(req: Request) {
  try {
    // 1) Validação opcional por segredo
    if (PROXY_SECRET) {
      const h = req.headers.get("x-webhook-secret");
      if (!h || h !== PROXY_SECRET) {
        return json({ error: "Unauthorized" }, 401);
      }
    }

    // 2) Ler payload bruto do provedor
    const raw = await req.json().catch(() => ({}));

    // 3) Normalizar
    const normalized = normalizeIncoming(raw);

    // 4) Enriquecer com metadados próprios (opcional: Supabase/DB)
    const meta = await lookupContext(normalized.messageId, normalized.reply_to).catch(() => null);
    const enriched = { ...normalized, meta };

    // 5) Encaminhar ao n8n
    const n8nRes = await safeFetch(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(enriched),
    });

    if (!n8nRes.ok) {
      const txt = await n8nRes.text();
      return json({ error: `n8n respondeu ${n8nRes.status}`, body: txt }, 502);
    }

    // 6) Se modo sync, ler decisão do n8n e opcionalmente responder via provedor
    if (FORWARD_AND_REPLY_SYNC) {
      let decision: N8nDecision | null = null;
      try { decision = await n8nRes.json(); } catch { /* pode não ter body */ }

      const replyText = (decision as any)?.replyText as string | undefined;
      const action = (decision as any)?.action as string | undefined;

      if ((action === "reply" || replyText) && replyText?.trim()) {
        const quoted = Boolean((decision as any)?.quoted ?? true);
        const mediaUrl = (decision as any)?.mediaUrl as string | undefined;

        const sent = await sendReplyViaProvider({
          type: PROVIDER_TYPE,
          baseUrl: PROVIDER_BASE_URL,
          token: PROVIDER_TOKEN,
          to: normalized.from!, // responder para quem mandou
          text: replyText,
          quotedMessageId: quoted ? (normalized.messageId || normalized.reply_to || undefined) : undefined,
          mediaUrl,
        });

        if (!sent.ok) {
          return json({ ok: false, error: sent.error || "Falha ao enviar resposta" }, 502);
        }

        return json({ ok: true, mode: "sync", replied: true });
      }

      // n8n decidiu não responder
      return json({ ok: true, mode: "sync", replied: false });
    }

    // 7) Modo async: n8n é quem envia
    return json({ ok: true, mode: "async" });
  } catch (e: any) {
    return json({ error: e?.message || "Erro" }, 500);
  }
}

// ==== Normalização ====
function normalizeIncoming(raw: any): Normalized {
  // Evolution-like
  if (raw?.message && (raw?.message?.text || raw?.message?.id)) {
    return {
      provider: "evolution",
      instance: raw?.instance,
      from: raw?.message?.from,
      to: raw?.message?.to,
      text: raw?.message?.text || raw?.message?.body || raw?.message?.message,
      timestamp: Number(raw?.message?.timestamp || Date.now()),
      messageId: raw?.message?.id,
      isGroup: Boolean(raw?.message?.isGroup),
      reply_to: raw?.message?.replyToMessageId || null,
      raw,
    };
  }

  // Uazapi-like
  if (raw?.data?.message || raw?.data?.key) {
    return {
      provider: "uazapi",
      instance: raw?.instance || raw?.data?.instance,
      from: raw?.data?.key?.remoteJid || raw?.data?.from,
      to: raw?.data?.key?.participant || raw?.data?.to,
      text:
        raw?.data?.message?.conversation ||
        raw?.data?.message?.extendedTextMessage?.text ||
        raw?.data?.message?.imageMessage?.caption ||
        "",
      timestamp: Number(raw?.data?.messageTimestamp || Date.now()),
      messageId: raw?.data?.key?.id,
      isGroup: String(raw?.data?.key?.remoteJid || "").includes("@g.us"),
      reply_to: raw?.data?.quoted?.stanzaId || null,
      raw,
    };
  }

  // Fallback genérico
  return {
    provider: raw?.provider || "unknown",
    instance: raw?.instance,
    from: raw?.from,
    to: raw?.to,
    text: raw?.text || raw?.body || "",
    timestamp: Number(raw?.timestamp || Date.now()),
    messageId: raw?.messageId || raw?.id,
    isGroup: Boolean(raw?.isGroup),
    reply_to: raw?.reply_to || null,
    raw,
  };
}

// ==== Enriquecimento (DB/lookup) ====
// Substitua por sua consulta real (ex.: Supabase) usando messageId/reply_to
async function lookupContext(messageId?: string, replyTo?: string | null) {
  // Exemplo: buscar por messageId → { batchId, listaId, contato, campanha }
  // Retorne null se não achar.
  // const { data } = await supabase.from('msgs').select('*').eq('message_id', messageId).single();
  return null as any;
}

// ==== Envio via Provedor ====
async function sendReplyViaProvider(opts: {
  type: "evolution" | "uazapi" | "outro";
  baseUrl: string;
  token: string;
  to: string; // msisdn/jid destino
  text: string;
  quotedMessageId?: string;
  mediaUrl?: string;
}): Promise<{ ok: boolean; error?: string }> {
  try {
    if (!opts.token) return { ok: false, error: "Token do provedor ausente" };

    if (opts.type === "evolution") {
      // Exemplos ilustrativos — ajuste ao seu provedor Evolution/API
      const url = `${opts.baseUrl.replace(/\/$/, "")}/messages/send`;
      const body: any = {
        to: opts.to,
        text: opts.text,
      };
      if (opts.quotedMessageId) body.replyTo = opts.quotedMessageId;
      if (opts.mediaUrl) body.mediaUrl = opts.mediaUrl; // se a API suportar

      const r = await safeFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${opts.token}`,
        },
        body: JSON.stringify(body),
      });
      if (!r.ok) return { ok: false, error: `Evolution status ${r.status}` };
      return { ok: true };
    }

    if (opts.type === "uazapi") {
      // Exemplos ilustrativos — ajuste ao seu provedor Uazapi/API
      const url = `${opts.baseUrl.replace(/\/$/, "")}/messages/send`;
      const body: any = {
        chatId: opts.to, // alguns pedem jid completo ("5511999999999@s.whatsapp.net")
        text: opts.text,
      };
      if (opts.quotedMessageId) body.quotedMsgId = opts.quotedMessageId;
      if (opts.mediaUrl) body.mediaUrl = opts.mediaUrl;

      const r = await safeFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: opts.token, // uazapi costuma usar header apikey
        } as any,
        body: JSON.stringify(body),
      });
      if (!r.ok) return { ok: false, error: `Uazapi status ${r.status}` };
      return { ok: true };
    }

    // Outro provedor — padronize aqui
    const url = `${opts.baseUrl.replace(/\/$/, "")}/messages/send`;
    const r = await safeFetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${opts.token}`,
      },
      body: JSON.stringify({ to: opts.to, text: opts.text, replyTo: opts.quotedMessageId, mediaUrl: opts.mediaUrl }),
    });
    if (!r.ok) return { ok: false, error: `status ${r.status}` };
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message || "Falha no envio" };
  }
}

// ==== util: fetch com retry exponencial simples ====
async function safeFetch(input: RequestInfo | URL, init?: RequestInit, retries = 2): Promise<Response> {
  let attempt = 0;
  let lastErr: any = null;
  while (attempt <= retries) {
    try {
      const ctrl = new AbortController();
      const id = setTimeout(() => ctrl.abort(), 15000); // 15s timeout
      const res = await fetch(input, { ...init, signal: ctrl.signal });
      clearTimeout(id);
      return res;
    } catch (e) {
      lastErr = e;
      await wait(300 * Math.pow(2, attempt));
      attempt++;
    }
  }
  throw lastErr || new Error("safeFetch failed");
}

function wait(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

// ==== util: resposta JSON ====
function json(payload: any, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}
