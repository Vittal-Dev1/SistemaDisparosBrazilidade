import { NextResponse } from 'next/server';
import { getServiceRoleClient } from '../../../lib/supabaseServer';

export const runtime = 'nodejs';

type Contato = Record<string, string>;
type TemplateVariation = { base: string; variations: string[] };
interface ListaBody {
  nome: string;
  templates: TemplateVariation[];
  replyTemplates?: TemplateVariation[] | null;
  contatos: Contato[];
  settings?: Record<string, any>;
}

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const supabase = getServiceRoleClient();
  try {
    const listId = Number(params.id);
    if (!listId) return NextResponse.json({ error: 'ID inválido' }, { status: 400 });

    const { data, error } = await supabase
      .from('listas_disparos')
      .select('*')
      .eq('id', listId)
      .maybeSingle();

    if (error) {
      console.error('💥 Supabase GET:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    if (!data) return NextResponse.json({ error: 'Lista não encontrada' }, { status: 404 });

    return NextResponse.json({
      ...data,
      id: data.id,
      nome: data.nome ?? '',
      templates: data.templates ?? [],
      reply_templates: data.reply_templates ?? [],
      contatos: data.contatos ?? [],
      settings: data.settings ?? {},
    });
  } catch (e: any) {
    console.error('💥 GET /api/listas/[id]:', e);
    return NextResponse.json({ error: e?.message || 'Erro interno' }, { status: 500 });
  }
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  const supabase = getServiceRoleClient();
  try {
    const listId = Number(params.id);
    if (!listId) return NextResponse.json({ error: 'ID inválido' }, { status: 400 });

    const body = (await req.json()) as ListaBody;
    if (!body?.nome?.trim() || !Array.isArray(body.templates) || !Array.isArray(body.contatos)) {
      return NextResponse.json({ error: 'Dados inválidos' }, { status: 400 });
    }

    const { data: exists, error: exErr } = await supabase
      .from('listas_disparos')
      .select('id')
      .eq('id', listId)
      .maybeSingle();

    if (exErr) {
      console.error('💥 Supabase GET-exists:', exErr);
      return NextResponse.json({ error: exErr.message }, { status: 500 });
    }
    if (!exists) return NextResponse.json({ error: 'Lista não encontrada' }, { status: 404 });

    const payload = {
      nome: body.nome.trim(),
      templates: body.templates,
      reply_templates: body.replyTemplates ?? null,
      contatos: body.contatos,
      settings: body.settings ?? {},
      updated_at: new Date().toISOString(),
    };

    const { data: updated, error: upErr, status } = await supabase
      .from('listas_disparos')
      .update(payload)
      .eq('id', listId)
      .select('id')
      .maybeSingle();

    if (upErr) {
      console.error('💥 Supabase UPDATE:', upErr);
      return NextResponse.json({ error: upErr.message }, { status: 500 });
    }

    if (!updated && status !== 204) {
      console.warn(`⚠️ PUT listas/${listId}: nenhuma linha retornada (status ${status}).`);
      return NextResponse.json({ error: 'Falha ao atualizar' }, { status: 500 });
    }

    return NextResponse.json({ id: updated?.id ?? listId, updated: true });
  } catch (e: any) {
    console.error('💥 PUT /api/listas/[id]:', e);
    return NextResponse.json({ error: e?.message || 'Erro interno' }, { status: 500 });
  }
}