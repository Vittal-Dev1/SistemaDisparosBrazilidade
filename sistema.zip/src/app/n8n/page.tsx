// =============================================
// N8N — Ativar Webhook (Next.js / App Router)
// =============================================
// Este arquivo contém 3 partes para você copiar nos lugares certos do seu projeto:
// 1) Página React (app/n8n/page.tsx)
// 2) API Route: POST /api/n8n/activate  (app/api/n8n/activate/route.ts)
// 3) API Route: POST /api/webhooks/inbound  (app/api/webhooks/inbound/route.ts)
//    → Proxy opcional que repassa o evento ao n8n e ANEXA contexto adicional (batchId, listaId, etc.)
//
// Objetivo: permitir que as respostas (replies) dos contatos sejam entregues ao seu fluxo n8n
// com o mesmo contexto da mensagem original (ex.: batchId, listaId, messageId do provedor),
// seja enviando DIRETO Provedor → n8n, seja via PROXY Next.js → n8n com enriquecimento de dados.
//
// Como funciona (resumo):
// - Você escolhe o modo de entrega (Direto ou Proxy).
// - No modo Proxy, você configura o endpoint público do Next.js (/api/webhooks/inbound)
//   no seu provedor de WhatsApp (Evolution API / Uazapi / etc.).
// - O Proxy valida/normaliza o evento e o encaminha ao webhook do seu fluxo n8n,
//   adicionando campos como reply_to, thread/conversation, batchId/listaId (se existirem no seu DB).
// - O n8n recebe SEMPRE no mesmo formato consistente (json), facilitando o roteamento.
//
// Observação importante: cada provedor de WhatsApp tem uma forma diferente de "setar" o webhook.
// Aqui deixo um endpoint genérico (/api/n8n/activate) para você salvar as preferências
// e testar o webhook do n8n, mas o "set" no provedor deve usar a API específica dele
// (ex.: Evolution tem /webhook e /settings; Uazapi tem /instance/update-webhook, etc.).
// Deixo ganchos no código para você plugar a chamada exata do seu provedor.

// ============================
// 1) Página React (app/n8n/page.tsx)
// ============================
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Save, Send, CheckCircle2, TriangleAlert, TestTube2, ShieldCheck, Link as LinkIcon } from "lucide-react";

export default function N8NActivatePage() {
  const [provider, setProvider] = useState<"evolution" | "uazapi" | "outro">("evolution");
  const [providerBaseUrl, setProviderBaseUrl] = useState("https://seu-provedor.com");
  const [providerToken, setProviderToken] = useState("");

  const [mode, setMode] = useState<"direct" | "proxy">("proxy");
  const [n8nWebhookUrl, setN8nWebhookUrl] = useState("https://seu-n8n.com/webhook/entrada-whatsapp");
  const [proxySecret, setProxySecret] = useState("");

  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<null | { type: "ok" | "err"; text: string }>(null);

  const show = (type: "ok" | "err", text: string) => setToast({ type, text });

  async function handleActivate() {
    try {
      setSaving(true);
      const res = await fetch("/api/n8n/activate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider,
          providerBaseUrl,
          providerToken,
          mode,
          n8nWebhookUrl,
          proxySecret,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Falha ao salvar");
      show("ok", json?.message || "Configuração salva");
    } catch (e: any) {
      show("err", e.message || "Erro ao salvar");
    } finally {
      setSaving(false);
    }
  }

  async function testWebhook() {
    try {
      setSaving(true);
      const res = await fetch("/api/n8n/activate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ test: true, n8nWebhookUrl }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Falha ao testar");
      show("ok", "Teste enviado. Verifique seu fluxo no n8n.");
    } catch (e: any) {
      show("err", e.message || "Erro ao testar");
    } finally {
      setSaving(false);
    }
  }

  const proxyEndpoint = typeof window !== "undefined" ? `${window.location.origin}/api/webhooks/inbound` : ".";

  return (
    <div className="min-h-dvh bg-zinc-950 text-zinc-200">
      <div className="max-w-3xl mx-auto px-6 py-10 space-y-8">
        <header>
          <h1 className="text-2xl font-semibold">Integração de Respostas → n8n</h1>
          <p className="text-zinc-400 text-sm mt-1">
            Configure o recebimento de respostas dos contatos diretamente no seu fluxo do n8n.
          </p>
        </header>

        {/* Modo de entrega */}
        <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-5 space-y-4">
          <h2 className="text-lg font-medium">Modo de entrega</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="rounded-2xl border border-white/10 p-4 flex items-start gap-3 cursor-pointer">
              <input
                type="radio"
                className="mt-1"
                checked={mode === "direct"}
                onChange={() => setMode("direct")}
              />
              <div>
                <div className="font-medium">Direto: Provedor → n8n</div>
                <p className="text-sm text-zinc-400">
                  O provedor envia os eventos diretamente para seu webhook do n8n.
                  *Você precisa configurar o webhook no painel/API do provedor.*
                </p>
              </div>
            </label>

            <label className="rounded-2xl border border-white/10 p-4 flex items-start gap-3 cursor-pointer">
              <input
                type="radio"
                className="mt-1"
                checked={mode === "proxy"}
                onChange={() => setMode("proxy")}
              />
              <div>
                <div className="font-medium">Proxy: Provedor → Next.js → n8n</div>
                <p className="text-sm text-zinc-400">
                  Recomendado. Permite enriquecer o evento com contexto (batchId, listaId, reply_to) e assinar com segredo.
                </p>
              </div>
            </label>
          </div>

          {mode === "proxy" && (
            <div className="rounded-xl border border-white/10 p-4 mt-2">
              <div className="text-sm text-zinc-400 mb-2">Endpoint público para configurar no seu provedor:</div>
              <div className="flex items-center gap-2">
                <LinkIcon className="h-4 w-4 text-zinc-400" />
                <code className="text-xs break-all">{proxyEndpoint}</code>
              </div>
            </div>
          )}
        </section>

        {/* Provedor */}
        <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-5 space-y-4">
          <h2 className="text-lg font-medium">Provedor</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <label className="block space-y-1.5">
              <span className="text-xs text-zinc-400">Tipo</span>
              <select
                className="w-full rounded-xl bg-zinc-950/60 border border-zinc-800 px-3.5 py-2.5 text-sm focus:ring-2 focus:ring-violet-500/60"
                value={provider}
                onChange={(e) => setProvider(e.target.value as any)}
              >
                <option value="evolution">Evolution API</option>
                <option value="uazapi">Uazapi</option>
                <option value="outro">Outro</option>
              </select>
            </label>

            <label className="block space-y-1.5 md:col-span-2">
              <span className="text-xs text-zinc-400">Base URL do provedor</span>
              <input
                value={providerBaseUrl}
                onChange={(e) => setProviderBaseUrl(e.target.value)}
                placeholder="https://seu-provedor.com"
                className="w-full rounded-xl bg-zinc-950/60 border border-zinc-800 px-3.5 py-2.5 text-sm"
              />
            </label>
          </div>

          <label className="block space-y-1.5">
            <span className="text-xs text-zinc-400">Token / API Key do provedor</span>
            <input
              type="password"
              value={providerToken}
              onChange={(e) => setProviderToken(e.target.value)}
              placeholder="API_KEY"
              className="w-full rounded-xl bg-zinc-950/60 border border-zinc-800 px-3.5 py-2.5 text-sm"
            />
          </label>
        </section>

        {/* n8n */}
        <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-5 space-y-4">
          <h2 className="text-lg font-medium">Webhook do n8n</h2>
          <label className="block space-y-1.5">
            <span className="text-xs text-zinc-400">URL do webhook (produção do seu fluxo)</span>
            <input
              value={n8nWebhookUrl}
              onChange={(e) => setN8nWebhookUrl(e.target.value)}
              placeholder="https://seu-n8n.com/webhook/entrada-whatsapp"
              className="w-full rounded-xl bg-zinc-950/60 border border-zinc-800 px-3.5 py-2.5 text-sm"
            />
          </label>

          {mode === "proxy" && (
            <label className="block space-y-1.5">
              <span className="text-xs text-zinc-400">Segredo do Proxy (X-Webhook-Secret)</span>
              <input
                type="password"
                value={proxySecret}
                onChange={(e) => setProxySecret(e.target.value)}
                placeholder="Defina um segredo para validar chamadas"
                className="w-full rounded-xl bg-zinc-950/60 border border-zinc-800 px-3.5 py-2.5 text-sm"
              />
            </label>
          )}

          <div className="flex flex-wrap gap-3 pt-2">
            <button
              onClick={handleActivate}
              className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold text-white bg-violet-600 hover:bg-violet-700"
              disabled={saving}
            >
              {saving ? <ShieldCheck className="h-4 w-4 animate-pulse" /> : <Save className="h-4 w-4" />}
              Salvar / Ativar
            </button>
            <button
              onClick={testWebhook}
              className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm border border-zinc-800 hover:bg-white/5"
              disabled={saving}
            >
              <TestTube2 className="h-4 w-4" /> Testar n8n
            </button>
          </div>
        </section>

        {/* Toast */}
        <AnimatePresence>
          {toast && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50"
            >
              <div
                className={`flex items-center gap-2 rounded-2xl px-4 py-3 shadow-xl ${
                  toast.type === "ok" ? "bg-emerald-600 text-white" : "bg-rose-600 text-white"
                }`}
              >
                {toast.type === "ok" ? <CheckCircle2 className="h-4 w-4" /> : <TriangleAlert className="h-4 w-4" />}
                <span className="text-sm font-medium">{toast.text}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

