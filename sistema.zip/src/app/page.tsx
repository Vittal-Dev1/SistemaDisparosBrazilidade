"use client";

import { useEffect, useState } from "react";
import LoginPage from "../app/login/page";
import Page from "../app/teste/page";


export default function Root() {
  const [auth, setAuth] = useState<null | boolean>(null);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return setAuth(false);

    fetch("/api/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    })
      .then(res => res.ok)
      .then(valid => setAuth(valid))
      .catch(() => setAuth(false));
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.reload();
  };

  if (auth === null) return <div className="flex h-screen items-center justify-center text-zinc-500">Verificando sessão...</div>;
  if (!auth) return <LoginPage onLogin={() => setAuth(true)} />;

  return (
    <div className={dark ? "bg-zinc-900 min-h-screen" : "bg-zinc-100 min-h-screen"}>
      <Page />
    </div>
  );
}